public enum TileType {

	Fruit,

	SnakeHead,

	SnakeBody

}
